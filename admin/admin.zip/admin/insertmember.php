<?php 
include_once("adminheader3.php");
?>
<h3 class="header smaller lighter blue">Member Details</h3>
								<form class="form-horizontal" role="form" method="post">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Member Name: </label>	
										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Member Name" name="txtusername" class="col-xs-10 col-sm-5" />
										</div>
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Member Password: </label>
										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Password" name="txtpassword" class="col-xs-10 col-sm-5" />
										</div>
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> First Name: </label>
										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="First Name" name="txtfname" class="col-xs-10 col-sm-5" />
										</div>
                                       <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Last Name: </label>
										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Last Name" name="txtlname" class="col-xs-10 col-sm-5" />
										</div>
                                       <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Member Image: </label>
										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Image" name="txtimg" class="col-xs-10 col-sm-5" />
										</div>
                                       <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Email: </label>
										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Email" name="txtemail" class="col-xs-10 col-sm-5" />
										</div>
                                       <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Contactno: </label>
										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Contactno" name="txtcontactno" class="col-xs-10 col-sm-5" />
										</div>
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Height: </label>
										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Height" name="txtheight" class="col-xs-10 col-sm-5" />
										</div>
                                       <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Weight: </label>
										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Weight" name="txtweight" class="col-xs-10 col-sm-5" />
										</div>
                                       
                                       <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Date of Joined: </label>
										<div class="col-sm-9"> 
											<input type="text" id="form-field-1" placeholder="DOJ" name="txtdoj" class="col-xs-10 col-sm-5" />
										</div>
                                       <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Date Of Birth: </label>
										<div class="col-sm-9">
											<input type="text" id="form-field-1" placeholder="Birthdate" name="txtdob" class="col-xs-10 col-sm-5" />
										</div>
                                       
                                        
								

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input type="submit" class="btn btn-info"
                                                   name="Submit">
								
											

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
									</div>
								</form>

<?php 
	
	if(isset($_POST['Submit'])){
        echo "hi";

		$uname=$_POST['txttuname'];
		$pwd=$_POST['txtpassword'];
		$fname=$_POST['txtfirstname'];
        $lname=$_POST['txtlastname'];
        $img=$_POST['txtimg'];
        $email=$_POST['txtemail'];
        $contactno=$_POST['txtcontactno'];
        $height=$_POST['txtheight'];
        $weight=$_POST['txtweight'];
        $doj=$_POST['txtdoj'];
        $dob=$_POST['txtdob'];
        		
        $cnn=mysqli_connect("localhost","root","","dbproject.sql");
		$qry="INSERT INTO member(uname,pwd,fname,lname,img,email,contactno,height,weight,doj,dob) VALUES ('$uname','$tpwd','$fname','$lname','$img','$email','$contactno','$height','$weight','$doj','$dob')";
		echo $qry;
		$result=$cnn->query($qry);
	}
?>								

<?php 
include_once("footer.php");
?>