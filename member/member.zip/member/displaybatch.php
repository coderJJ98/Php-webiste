<?php
include_once("memberheader.php");
?>

<h3 class="header smaller lighter blue"> Batch details</h3>

<?php
                                   
                                    $mid=$_SESSION["mid"];
                                $uname=$_SESSION["uname"];                                
    
                                    //$fname=$_SESSION["fullname"];
                                  
        $cnn=mysqli_connect("localhost","root","","dbproject.sql");
		$qry="select * from member where batchid=$mid";
		$result=$cnn->query($qry);

		while($row=$result->fetch_assoc())
		{
            
            $uname=$row["uname"];
            $fullname=$row["fname"]." ".$row["lname"];
            $height=$row["height"];
            $weight=$row["weight"];
            $doj=$row["doj"];
            $dob=$row["dob"];
            $email=$row["email"];
            $contactno=$row["contactno"];
            
        }
          
                               
?>


<?php
include_once("footer.php");
?>